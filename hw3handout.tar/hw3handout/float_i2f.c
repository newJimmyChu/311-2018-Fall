#include "float_i2f.h"
float_bits float_i2f(int i) {
  return 0;
}
